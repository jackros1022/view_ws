# navigator

Modified version of PS8.  Many unused nodes and code were removed.

## Example usage

```
$ rosrun beta_navigator beta_navigator
```

Make calls using `beta_navigator/navigator.action` action messages.

This should all be coordinated by the `coordinator` package.
